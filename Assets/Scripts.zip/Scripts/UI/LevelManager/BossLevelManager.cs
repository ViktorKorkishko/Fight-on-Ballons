﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BossLevelManager : LevelManager
{
    [SerializeField] GameObject enemies;
    public override void UpdateLevelManager()
    {
        
    }
}
